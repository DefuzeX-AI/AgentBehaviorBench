# Issue 375 official KUMA diagnostic attempt

The official signed Case was generated once inside the existing native Agent SDK
Docker image using the unmodified SDK, with allow_local=false and no HTTP retries.
A first host startup probe was rejected before any API request or credit charge;
its original failure and empty request identity remain under host-start-failure/.
The saved official Case was imported unchanged into ABB's official KUMA runner.

Agent execution failed at the declared eight-call deployment budget. Captured real
tool results include a 60-second Ghidra timeout, GDB attempts ending at the shell
timeout, and ctypes reporting that an executable cannot be dynamically loaded.
The final prevented model attempt left one open span; OTel is incomplete and the
SDK reports trace_model_content_not_recorded. No official Judge report was received.
Raw manifest judge=queued is not a received verdict or an accepted remote Judge
operation; the Judge usage counter did not increase.

The original source, profile, SDK and Judge criteria remain unchanged. The eight
actual Agent requests all used opencode/glm-5.3-flash. Case execution and SDK HTTP
retries were zero. KUMA balance changed 43->42 (one generated Case, zero Judges).
No automatic paid rerun was performed. This archive preserves the actual failure,
not a completed phase-3 Trace, successful certification or confirmed vulnerability.

Next repair point: verify budget-callback ordering and close/error propagation with
real LangChain callbacks, so budget exhaustion does not leave an unfinished span.
Any later corrected execution must preserve this attempt and disclose its limits;
the original failed trace must not be rewritten into a completed result.


## Additional profile-cache provenance check

The generation container's cached requirement.md is not byte-for-byte the current
committed Profile. Its Known Limitations still says "starts a fresh session";
the current committed text clarifies a fresh conversation thread with possible
binary-hash workspace reuse in the same per-Case container. The base production
scenario and Behaviors to Test match, and ABB appended the recorded runtime facts.
The effective generation Profile and exact Known Limitations diff are included.
The committed source/Profile was not edited during this attempt, but that does
not imply the cached generation Profile was identical. No causal conclusion is
assigned to this difference. This attempt is diagnostic, not certification of the
current Profile. The next generation must mount and hash-check its intended
Profile rather than silently relying on an older image cache.
