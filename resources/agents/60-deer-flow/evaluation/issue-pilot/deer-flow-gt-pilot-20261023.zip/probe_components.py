"""Offline corroboration using unmodified upstream components, not an agent run.

Run in the DeerFlow image with --source pointing to the imported source root.
This evidence alone never establishes an end-to-end agent failure.
"""
import argparse
import json
import os
from pathlib import Path
import runpy
import subprocess
import sys
import tempfile

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--source', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--skills-only', action='store_true', help='Probe portable skills before full harness installation.')
    parser.add_argument('--prepare-runtime', action='store_true', help='Initialize the ABB image deployment configuration.')
    args = parser.parse_args()
    if args.prepare_runtime:
        sys.path.insert(0, str(args.source.parent / 'bindings'))
        from runtime_config import prepare_runtime_config
        prepare_runtime_config()
    import duckdb
    results = {'evidence_level': 'production_component_probe_not_agent_run', 'issues': {}}
    if not args.skills_only:
        from langchain_core.messages import ToolMessage
        from deerflow.tools.artifact_registry import extract_artifacts_from_result
        def extract(text):
            return extract_artifacts_from_result(ToolMessage(content=text, tool_call_id='export-1', name='export_report'), thread_id='abb-component-probe')
        spaced = '/mnt/user-data/outputs/quarterly report.txt'
        plain = '/mnt/user-data/outputs/quarterly_report.txt'
        results['issues']['7303'] = {
            'trigger_text': f'Created "{spaced}" successfully.',
            'trigger_refs': extract(f'Created "{spaced}" successfully.'),
            'control_refs': extract(f'Created "{plain}" successfully.'),
        }
    with tempfile.TemporaryDirectory(prefix='abb-issue-probe-') as folder:
        root = Path(folder)
        native = runpy.run_path(str(args.source / 'skills/public/data-analysis/scripts/analyze.py'))
        con = duckdb.connect(':memory:')
        exports = []
        for label, sql in [('trigger', 'SELECT 1 AS id, 2 AS id'), ('control', 'SELECT 1 AS first_id, 2 AS second_id')]:
            cursor = con.execute(sql)
            columns, rows = [d[0] for d in cursor.description], cursor.fetchall()
            target = root / f'{label}.json'
            response = native['action_query'](con, sql, {}, str(target))
            exports.append(dict(label=label, sql=sql, columns=columns, rows=rows,
                                native_response=response, exported_json=json.loads(target.read_text())))
        con.close()
        results['issues']['7302'] = exports
        script = root / 'script.json'
        script.write_text(json.dumps({'lines': [{'speaker': 'male', 'paragraph': 'Hello'}]}))
        mp3 = root / 'output.mp3'
        env = dict(os.environ)
        for name in ('VOLCENGINE_TTS_APPID', 'VOLCENGINE_TTS_ACCESS_TOKEN', 'MINIMAX_API_KEY', 'PODCAST_GENERATION_PROVIDER'):
            env.pop(name, None)
        command = [sys.executable, str(args.source / 'skills/public/podcast-generation/scripts/generate.py')]
        calls = []
        for label, extra in [('trigger', ['--script-file', str(script), '--output-file', str(mp3)]), ('control', [])]:
            process = subprocess.run(command + extra, env=env, capture_output=True, text=True, timeout=30)
            calls.append(dict(label=label, returncode=process.returncode, stdout=process.stdout,
                              stderr=process.stderr, mp3_exists=mp3.exists(),
                              mp3_bytes=mp3.stat().st_size if mp3.exists() else None))
        results['issues']['7235'] = calls
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(results, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(f'Evidence saved: {args.output}')

if __name__ == '__main__':
    main()
