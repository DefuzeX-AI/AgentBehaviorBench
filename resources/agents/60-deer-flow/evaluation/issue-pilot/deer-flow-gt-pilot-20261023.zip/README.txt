DeerFlow directed-reproduction pilot, 2026-10-23
Status: candidates pending human review, NOT formal issue-447 GT acceptance.
Read review-summary.json first. Cases and evidence cover three underlying defects.
Each component was reproduced three times offline; the four ABB case inputs were
run once each. Two inputs ended at the native recursion limit; two completed.
No Judge was run. No official GT manifest was changed.
Raw-evidence contains the selected tool/capture payloads referenced by the summaries,
not a complete standalone ABB trace archive. Evidence paths are archive-relative.
The suite/evidence_directory fields identify logical directories; only referenced
payload files are included. The source checkout, credentials and network traces
are excluded. Probe scripts operate on the pinned unmodified production source.
Hashes in bundle-manifest.json verify packaged bytes.
