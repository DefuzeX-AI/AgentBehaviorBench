"""Test suite for CRA-AGENT."""
