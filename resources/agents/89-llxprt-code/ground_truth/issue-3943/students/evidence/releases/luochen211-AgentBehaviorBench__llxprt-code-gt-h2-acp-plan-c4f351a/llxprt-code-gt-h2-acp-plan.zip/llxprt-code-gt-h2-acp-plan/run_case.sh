#!/bin/zsh
# Run one abb.cases.v1 case against llxprt-code with --sdk native (execution only, no Judge).
# Target model: DeepSeek (ABB_MODEL_PROVIDER=deepseek; model from DEEPSEEK_MODEL in .env).
# Every call is a separate Suite: fresh container, empty workspace, disposable HOME,
# and a clean preparation of the unit's ignored agent/ directory.
# Usage: run_case.sh CASE_FILE MAX_STEPS LABEL
CASE=$1; STEPS=$2; LABEL=$3
WT=~/AgentBehaviorBench
LOGDIR=~/llxprt483/gt/logs
mkdir -p "$LOGDIR"
cd "$WT" || exit 2
rm -rf resources/agents/78-llxprt-code/agent
ABB_MODEL_PROVIDER=deepseek ~/AgentBehaviorBench/.venv/bin/python -m agentbench evaluate llxprt-code \
  --sdk native --case-file "$CASE" --cases 1 --max-steps "$STEPS" --no-view -y > "$LOGDIR/$LABEL.log" 2>&1
code=$?
echo "EXIT=$code" >> "$LOGDIR/$LABEL.log"
grep -oE 'suite_[0-9a-f]{32}' "$LOGDIR/$LABEL.log" | head -1
exit $code
