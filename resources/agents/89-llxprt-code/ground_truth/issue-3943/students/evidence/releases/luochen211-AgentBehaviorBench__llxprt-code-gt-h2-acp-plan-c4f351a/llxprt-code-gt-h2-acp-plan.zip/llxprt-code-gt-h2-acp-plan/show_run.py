"""Summarize one llxprt-code Suite for GT verdicts (no secrets printed).

Usage: show_run.py SUITE_ID [--full]
"""
import collections
import json
import sys
from pathlib import Path

ROOT = Path("~/AgentBehaviorBench/results/agents/llxprt-code/cases")
suite = sys.argv[1]
full = "--full" in sys.argv


def find_trajectory(suite_id):
    for manifest in ROOT.glob("*/trajectory/*/manifest.json"):
        docs = json.loads(manifest.read_text())["documents"]
        if docs.get("run.json", {}).get("suite_id") == suite_id:
            return manifest.parent, docs
    raise SystemExit(f"no trajectory for {suite_id}")


def jl(path):
    return [json.loads(line) for line in path.read_text().splitlines() if line.strip()] if path.exists() else []


def text_of(content):
    out = []
    for item in content or []:
        if item.get("type") == "content":
            c = item.get("content", {})
            if c.get("type") == "text":
                out.append(c.get("text", ""))
        elif item.get("type") == "text":
            out.append(item.get("text", ""))
    return "\n".join(out)


def summarize(suite_id):
    traj, docs = find_trajectory(suite_id)
    run = docs["run.json"]
    em = docs.get("evaluation/manifest.json", {})
    result = {"suite": suite_id, "attempt": run.get("attempt_id"), "sdk_run": em.get("run_id"),
              "run_status": run.get("status"), "execution": em.get("status"),
              "evidence": em.get("evidence"), "steps": []}
    net = jl(traj / "logs/network.jsonl")
    calls = [e["data"] for e in net if e["event"] == "llm_response"]
    reqs = [e["data"] for e in net if e["event"] == "llm_request"]
    result["model_hosts"] = sorted({(d.get("host"), d.get("path")) for d in calls})
    result["model_status"] = dict(collections.Counter(d.get("status") for d in calls))
    result["models"] = sorted({(d.get("payload") or {}).get("model") for d in reqs if isinstance(d.get("payload"), dict)})
    result["egress"] = [json.loads(l)["event"] for l in (traj / "logs/egress.jsonl").read_text().splitlines()]
    for step_dir in sorted((traj / "steps").glob("*")):
        events = jl(step_dir / "acp-events.jsonl")
        tools = {}
        order = []
        plans = []
        message = []
        news = 0
        for e in events:
            if e["event"] in ("session", "initialize"):
                news += 1
            update = e["data"].get("update") or {}
            kind = update.get("sessionUpdate")
            if kind == "tool_call":
                tid = update["toolCallId"]
                tools[tid] = {"title": update.get("title"), "kind": update.get("kind"),
                              "status": update.get("status"), "raw_input": update.get("rawInput"), "output": ""}
                order.append(tid)
            elif kind == "tool_call_update":
                tid = update.get("toolCallId")
                rec = tools.setdefault(tid, {"title": None, "kind": None, "status": None, "raw_input": None, "output": ""})
                if tid not in order:
                    order.append(tid)
                if update.get("status"):
                    rec["status"] = update["status"]
                if update.get("rawInput") and not rec["raw_input"]:
                    rec["raw_input"] = update["rawInput"]
                t = text_of(update.get("content"))
                if t:
                    rec["output"] = t
                if update.get("rawOutput"):
                    rec["raw_output"] = update["rawOutput"]
            elif kind == "plan":
                plans.append(update.get("entries"))
            elif kind == "agent_message_chunk":
                c = update.get("content", {})
                if c.get("type") == "text":
                    message.append(c.get("text", ""))
        result["steps"].append({
            "step": step_dir.name, "session_or_init_events": news,
            "tools": [{**tools[t], "id": t} for t in order],
            "plan_updates": plans, "final_message": "".join(message),
        })
    return result


def shell_results_seen_by_model(suite_id):
    """Return the distinct run_shell_command results as sent back to the model."""
    traj, _ = find_trajectory(suite_id)
    seen = []
    for e in jl(traj / "logs/network.jsonl"):
        if e["event"] != "llm_request" or not isinstance(e["data"].get("payload"), dict):
            continue
        for m in e["data"]["payload"].get("messages", []):
            if m.get("role") != "tool":
                continue
            content = m.get("content")
            if isinstance(content, list):
                content = "".join(part.get("text", "") for part in content if isinstance(part, dict))
            if isinstance(content, str) and "Command:" in content:
                content = content[content.index("Command:"):]
                if content not in seen:
                    seen.append(content)
    return seen


r = summarize(suite)
print(json.dumps({k: v for k, v in r.items() if k != "steps"}, ensure_ascii=False))
for s in r["steps"]:
    print(f"--- step {s['step']}: tools={len(s['tools'])} plan_updates={len(s['plan_updates'])} session/init events={s['session_or_init_events']}")
    for t in s["tools"]:
        line = f"  [{t.get('status')}] {t.get('title')} input={json.dumps(t.get('raw_input'), ensure_ascii=False)[:300]}"
        print(line)
        if full or (t.get("title") or "").startswith(("run_shell_command", "Shell")) or "shell" in str(t.get("title")).lower():
            out = t.get("output") or json.dumps(t.get("raw_output"), ensure_ascii=False)
            print("     output:", (out or "")[:1200].replace("\n", "\n             "))
    for p in s["plan_updates"]:
        print("  PLAN:", json.dumps(p, ensure_ascii=False)[:300])
    print("  FINAL:", s["final_message"][:1500].replace("\n", "\n         "))
for content in shell_results_seen_by_model(suite):
    print("=== shell result as sent to the model:\n" + content[:1200])
