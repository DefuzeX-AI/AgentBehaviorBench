# LLxprt Code GT hypotheses (#483)

Written before any execution, from the README, docs and source of tag v0.11.0
(`5400f65a`) and the tool definitions the model received in the step-1 acceptance
runs. No existing GT, KUMA defect report, upstream issue or PR was looked at.

Deployment: unit `resources/agents/78-llxprt-code` (PR #582), ACP stdio,
`--provider openai`. GT model: deepseek/deepseek-flash (`ABB_MODEL_PROVIDER=deepseek`).

## H1: shell results always say `Stderr: (empty)`; stderr text is reported as stdout

- Legal user task: run a command and say whether / what it wrote to stderr (for
  example because CI fails a job on any stderr output).
- Declared behavior: the `run_shell_command` description sent to the model
  (`packages/tools/src/tools/shell-helpers.ts:559`) says the result contains
  "Stdout: Output on stdout stream" and "Stderr: Output on stderr stream".
- Suspected source: `ShellToolInvocation.formatNormalOutput`
  (`packages/tools/src/tools/shell.ts:681-682`) writes the merged output as
  `Stdout:` and hardcodes `Stderr: (empty)`. In ACP mode the command runs in a
  client terminal (`zed-terminal-manager.ts`), which returns one merged stream.
- Trigger: a command that writes to stderr; the user asks about stderr; the agent
  does not separate the streams itself (`2>file`, `2>/dev/null`).
- Supports: the tool record shows the stderr text under `Stdout:` with
  `Stderr: (empty)`, and the agent's answer says nothing (or something wrong) was
  written to stderr / attributes the stderr line to stdout.
- Refutes: the agent correctly identifies the stderr line(s), or the tool result
  reports them under `Stderr:`.

## H2: todo list changes never reach the ACP client as `plan` updates

- Legal user task: ask the agent to plan multi-step work with its todo list and
  keep it updated, in an ACP (Zed) session.
- Declared behavior: the ACP session subscribes to todo updates and forwards them
  as ACP `plan` session updates (`packages/cli/src/zed-integration/zedIntegration.ts:472-480`,
  `zed-plan-update.ts`); `docs/todo-system.md` says the todo view "updates
  automatically every time the model modifies the list".
- Suspected source: the listener forwards only events whose `sessionId` equals the
  ACP session id (`randomUUID()` in `newSession`, `zedIntegration.ts:129`), but
  `todo_write` emits `this.context.sessionId` (`todo-write.ts:166`), which the tool
  dispatcher fills from `config.getSessionId()`
  (`packages/agents/src/scheduler/tool-dispatcher.ts:66`). The session-scoped config
  (`zed-session-config.ts`) does not override `getSessionId`, so it returns the
  process-level id and every event is filtered out.
- Trigger: any successful `todo_write` call in an ACP session.
- Supports: the step's ACP log has successful `todo_write` tool calls but no
  `session/update` with `sessionUpdate: "plan"`.
- Refutes: a `plan` update with the todo entries appears after `todo_write`.
- Not reached: no `todo_write` call in the run.
- ABB check: ABB's ACP client records every `session/update` it receives
  (`agentbench/adapter/acp/client.py:36-47`; other non-text updates such as
  `available_commands_update` and `session_info_update` are recorded).

## H3

Not used unless H1 and H2 are both rejected (at most 3 hypotheses).
