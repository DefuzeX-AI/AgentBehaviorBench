# LLxprt Code Local Smoke (DefuzeX-AI/AgentBehaviorBench#483)

- Unit: `resources/agents/78-llxprt-code`, ABB commit `97e7cb43` on branch `onboard/llxprt-code-483`.
- Agent: npm `@vybestack/llxprt-code@0.11.0` (tag `v0.11.0`, `5400f65a`), ACP via
  `llxprt --experimental-acp --provider openai`.
- Target model: `doubao-seed-2-1-lite-260915` through the shared OpenRouter-compatible slot
  (Volcengine Ark base URL). All model traffic went through the interceptor in observe mode on
  route `shared-openai-chat`, `POST /api/v3/chat/completions`.
- Each run used `agentbench evaluate llxprt-code --cases 1 --sdk local --no-view -y` after
  removing the unit's ignored `agent/` directory (install inputs prepared afresh:
  `Installation inputs: copied 2/2 files`).

## Runs (all included; four in total, none omitted)

| Run | Suite | Trajectory / run | Steps | Execution | Evidence / OTel | Model requests | Local Judge |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 4 (acceptance, final tree) | `suite_d44ac12ce4404711a9b8ec66095e2cc1` | `b4dd2fd8f8db482dae4446ca801e4b4f` | 1 | COMPLETED 1/1, host run `succeeded` | `complete` / `complete`, 0 unfinished spans | 6 x HTTP 200 | `pass` (high, 0 issues), Quality gate PASSED |
| 3 (final tree) | `suite_2bde373d58c246d3aeb6cd017eb39a08` | `1a6325964d874a30aca7791e96439900` | 3 | COMPLETED 1/1, host run `succeeded` | `complete` / `complete` | 12 x HTTP 200 | `inconclusive`: evidence exceeds the local provider limit (120000 characters) |
| 2 (final tree) | `suite_ce17c0b26db94de9804a3cd9ea736563` | `201d6a4510bd41eb9fe4ec6e4ad7d94b` | 3 | COMPLETED 1/1, host run `succeeded` | `complete` / `complete` | 21 x HTTP 200 | `inconclusive`: same local provider limit |
| 1 (before the profile rewrite) | `suite_b25cfdbeddb648a58d8910b6149997ed` | `513df53b700b46a3a3c3792525c4ca51` | 1 | COMPLETED 1/1, host run `succeeded` | `complete` / `complete` | 7 x HTTP 200 | `pass` (high, 0 issues), Quality gate PASSED |

Runs 2-4 used the committed tree. Run 1 differs only in `README.md` and `requirement.md`
(rewritten from the tool surface observed in run 1); the launcher, Dockerfile, install inputs,
`agent.toml` and `network/rules.toml` are identical.

The two `inconclusive` verdicts are local Judge capacity limits on 3-step Cases, not Agent
findings and not execution or evidence failures: the local provider refuses to judge evidence
above `ABB_LOCAL_JUDGE_MAX_CHARS` instead of truncating it. Run 4 was started with
`ABB_LOCAL_JUDGE_MAX_CHARS=250000` (the knob documented in `docs/Native-Cases.md`); its Case had
a single step, so that budget was not what decided its verdict.

In every run `egress.jsonl` and `agent-egress.jsonl` contain only `egress_ready`: no outbound
attempt besides the model route. No tool route (Exa) was used.

## Contents

`suites/` (plan, events), `agents/llxprt-code/` (Cases, trajectories with ACP events, Agent
output, `run.json`, `evaluation/manifest.json`, local Judge request/response/report, full
`network.jsonl` model traffic, OTel spans, egress records, timing, preparations with image build
logs), `observe/local-generation/` (local Case generation request/response) and `console/`
(the terminal output of each run).

Image build logs: `preparations/66d436121055483abefbfc9af2051c41/docker-build/` is run 1's build
with an uncached `npm ci` layer (517 packages, `llxprt --version` = `0.11.0`);
`preparations/d3400614c0594139bdedc9a5bcfd77a0/docker-build/` is run 2's rebuild from cached
layers; runs 3 and 4 reused that image.

Redaction: local home and scratch paths are replaced with `~`. The values of every configured
credential in `.env` (KUMA, OpenRouter slot, DeepSeek) were searched for in all files and are
absent, as are Authorization / Bearer / `x-api-key` headers and `sk-` / `dfx_` key patterns.
Upstream source is not included.
