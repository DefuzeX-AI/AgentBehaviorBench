#!/bin/zsh
# Ten independent runs of the frozen H2 case; each is its own Suite.
G=~/llxprt483/gt
for i in 01 02 03 04 05 06 07 08 09 10; do
  suite=$(zsh $G/run_case.sh $G/h2/case-v1.json 1 h2-v1-run$i)
  echo "run$i exit=$? $suite" >> $G/logs/h2-run10.out
done
echo ALL_DONE >> $G/logs/h2-run10.out
