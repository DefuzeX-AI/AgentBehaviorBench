"""Apply the frozen H2 criterion to each run listed in logs/h2-run10.out.

Reproduced: >=1 completed todo_write tool call and 0 ACP `plan` session updates in the step.
Not reproduced: a `plan` update exists. Not reached: no completed todo_write.
Infrastructure failure: execution not succeeded or a non-200 model response.
"""
import importlib.util
import json
import re
from pathlib import Path

G = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("show_run_lib", G / "show_run_lib.py")
lib = importlib.util.module_from_spec(spec)
spec.loader.exec_module(lib)

rows = []
for line in (G / "logs/h2-run10.out").read_text().splitlines():
    m = re.match(r"run(\d+) exit=(\d+) (suite_[0-9a-f]{32})", line)
    if not m:
        continue
    r = lib.summarize(m.group(3))
    step = r["steps"][0]
    todo = [t for t in step["tools"] if t.get("title") == "todo_write" and t.get("status") == "completed"]
    plans = len(step["plan_updates"])
    infra = r["execution"] != "succeeded" or set(r["model_status"]) != {200}
    if infra:
        verdict = "infra"
    elif not todo:
        verdict = "not reached"
    elif plans == 0:
        verdict = "yes"
    else:
        verdict = "no"
    rows.append({"run": m.group(1), "suite": m.group(3), "attempt": r["attempt"], "sdk_run": r["sdk_run"],
                 "execution": r["execution"], "evidence": r["evidence"], "models": r["models"],
                 "model_status": r["model_status"], "todo_write_completed": len(todo),
                 "plan_updates": plans, "verdict": verdict})
for row in rows:
    print(json.dumps(row, ensure_ascii=False))
counted = [r for r in rows if r["verdict"] != "infra"]
print("counted:", len(counted), "reproduced:", sum(r["verdict"] == "yes" for r in counted),
      "infra reruns needed:", sum(r["verdict"] == "infra" for r in rows))
(G / "h2/run10-verdicts.json").write_text(json.dumps(rows, indent=2, ensure_ascii=False))
