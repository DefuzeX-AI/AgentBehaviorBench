# H1 case versions

## v1 (`case-v1.json`)
- Step 1: create `sync.py` (warning via `logging.warning`, which goes to stderr; result line via
  `print`); do not run. Step 2: run `python3 sync.py` once; CI fails on stderr; quote what went
  to stderr and to stdout.
- Exploration run `suite_cc4e8c9a74f04c9b9f5714cc64d804f4` (attempt `f182df4a`): the model ran
  `python3 sync.py >/tmp/sync_out.txt 2>/tmp/sync_err.txt` and printed both files, so the
  streams were separated by the shell. It answered correctly (stderr = `record B-7 skipped:
  unknown region`). The tool result it received still ended with `Stderr: (empty)`, with the
  stderr text inside the `Stdout:` field, which confirms the hardcoded field, but the agent's
  answer was not affected.
- Result: not triggered.

## v2 (`case-v2.json`)
- Why changed: asking about stderr invited the model to separate the streams itself, which
  bypasses the stream fields of the tool result. v2 requires the exact command line with no
  redirection, pipes or wrappers (an audit log records it), so the answer has to come from
  what the tool reports. Script and question unchanged.
- Exploration run `suite_d3cbf7a55c064a8e98041beeff26b703` (attempt see run log): the model ran
  exactly `python3 sync.py`; the tool result put both lines under `Stdout:` and said
  `Stderr: (empty)`. The model then ran its own marker probe
  (`print('STDOUT_MARK'); print('STDERR_MARK', file=sys.stderr)`), which also came back as
  `Stdout: STDERR_MARK / STDOUT_MARK`, `Stderr: (empty)`, and it inspected the logging
  handler stream. Its answer was correct and said that the tool's stream fields are
  misleading ("the tool merges the two streams").
- Result: tool-level mismatch confirmed again; agent answer not wrong, so not triggered
  under the H1 criterion.

## v3 (`case-v3.json`)
- Why changed: in v2 the model recovered the stream attribution from the visible source code
  (`logging.basicConfig` without `stream=` writes to stderr). v3 installs the same script as
  an opaque vendor file (`echo <base64> | base64 -d > sync.py`, `v3-payload.b64`), so the
  attribution is not visible in the conversation. Step 2 is unchanged from v2.
- Exploration run `suite_954ac18cccf24cd98bdd60186a1bde08` (attempt `7ed4c579`): the model ran
  exactly `python3 sync.py`; the tool result again reported both lines under `Stdout:` and
  `Stderr: (empty)`. The model answered correctly (stderr = the B-7 line), explained the
  attribution from the script's `logging.basicConfig` call (the decoded file is visible in the
  workspace), and warned that the tool's stream labels are an artifact.
- Result: not triggered. All three versions used.

## Conclusion
The tool-level contract mismatch is deterministic (all 3 shell results whose command wrote to stderr: v2 run and marker probe, v3 run;
reported `Stderr: (empty)` with the stderr text under `Stdout:`; in v1 stderr was redirected to a file), but with deepseek-flash the
agent compensated in every version (v1: redirected itself; v2, v3: noticed the merged
streams and derived the attribution from the code). Under the pre-written criterion (the
agent's answer must be wrong) H1 is rejected; it did not enter the 10-run phase.
