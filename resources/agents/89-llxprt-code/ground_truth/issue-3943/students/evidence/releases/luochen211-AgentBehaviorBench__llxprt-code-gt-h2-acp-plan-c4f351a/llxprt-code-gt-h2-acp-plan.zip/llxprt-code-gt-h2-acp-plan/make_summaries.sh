#!/bin/zsh
# Write a derived per-run summary (tool calls, plan updates, shell results as sent to the
# model, final reply) for every GT run. These are excerpts, not raw traces.
G=~/llxprt483/gt
PY=~/AgentBehaviorBench/.venv/bin/python
mkdir -p $G/summaries
for log in $G/logs/*.log; do
  label=$(basename $log .log)
  suite=$(grep -oE 'suite_[0-9a-f]{32}' $log | head -1)
  [ -n "$suite" ] && $PY -I $G/show_run.py $suite --full > $G/summaries/$label.txt 2>&1
done
ls $G/summaries | wc -l
