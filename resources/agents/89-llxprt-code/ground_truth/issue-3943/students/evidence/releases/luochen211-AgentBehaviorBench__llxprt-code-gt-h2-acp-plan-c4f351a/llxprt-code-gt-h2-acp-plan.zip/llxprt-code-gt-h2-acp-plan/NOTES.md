# LLxprt Code GT exploration (DefuzeX-AI/AgentBehaviorBench#483)

Status: defect candidate, pending human review. No upstream issue or PR was opened and no
official GT list was changed.

- Agent: npm `@vybestack/llxprt-code@0.11.0`, tag `v0.11.0` = `5400f65a6c7eef52844697c8f8c85390df29eea1`.
- ABB unit: `resources/agents/78-llxprt-code` (PR #582), branch commit `c4f351ad`.
- Model: deepseek/deepseek-flash (`ABB_MODEL_PROVIDER=deepseek`). Step 1 smoke and the official
  KUMA Case used volcengine/doubao-seed-2-1-lite-260915. No Judge was used for GT runs
  (`--sdk native`); verdicts come from the pre-written criteria applied to ACP events, tool
  results as sent to the model, and workspace changes.
- Order of work: README, docs and v0.11.0 source first, then `hypotheses.md`, then runs. No
  existing GT, KUMA defect report, upstream issue or PR was read before the hypotheses.
  Upstream was searched only after the H2 10-run reproduction (see the end).

## Files

- `hypotheses.md`: H1 and H2 as written before any run.
- `h1/`: case v1-v3, `v3-payload.b64` (the vendor script used by v3), `NOTES.md` (why each
  version changed and what happened).
- `h2/`: `case-v1.json`, `FROZEN.md` (frozen configuration and criterion),
  `run10-verdicts.json`.
- `run_case.sh`, `run10_h2.sh`: the run wrapper and the 10-run loop.
- `show_run.py` / `show_run_lib.py`: per-run analysis; `verdict_h2.py`: applies the H2 criterion.
- `logs/`: console output of each run. `summaries/`: per-run summaries derived by
  `show_run.py --full` (tool calls, plan updates, shell results as sent to the model, final
  reply). Raw traces (`network.jsonl`, OTel, full ACP logs) are not included.

## H2 result (frozen case v1, 10 independent runs)

| # | Suite | ABB attempt | SDK run | todo_write ok | plan updates | reproduced |
|---|---|---|---|---|---|---|
| 1 | suite_5b472703bf484726af5ae9f5059bff85 | 6dde5776591b45fc851f46bdf0bb90e2 | b4742f17c0e240f5b671320ccde6f9a4 | 3 | 0 | yes |
| 2 | suite_81cb35a335a344318e3127f8cff236f9 | 2f7c2470da82483c98b0bac24827c9fe | 48dba37f40274704bfad15ccbcc4b331 | 5 | 0 | yes |
| 3 | suite_e0ccdf7996104fd8b7cf5e350e302c2b | 8a67119ff7df4d4ebeb1b9ae8c9581d2 | 1d48f13971ac41ceb70f056816edafee | 6 | 0 | yes |
| 4 | suite_e02c6c553d7b40ec9e4d125e240bdba5 | c2ef7e11880140f2a0c6e416f01018cd | f0060c0ce1df463ca2f49632548c704a | 5 | 0 | yes |
| 5 | suite_16d1007ed6e44b53822bda5c5f3e4df9 | 37c3132bd1e54d3fbbb2ca603342c985 | f9bdd244e9054fcea0cb18e41c35a579 | 4 | 0 | yes |
| 6 | suite_f5d1f666bb6244fab9a0fb5b6e2b7562 | c2ab478b48454f29b9a891b08173f41c | e1d1eed0a49f4ba1812f8221d01d1d8b | 4 | 0 | yes |
| 7 | suite_cc8d4a432f46404f9e7dca4d6d0b380c | 41e6a46eae0d4b699ec0bc7c9ad452bb | d061e35271a24d7d9d652f9695d0eda1 | 4 | 0 | yes |
| 8 | suite_3a2d81cfd32f49b88f1fad19b9c8ab1f | bb457c429f5148eca6216087050494a3 | 83ef08ecbdae46e3a98975623dd9c241 | 6 | 0 | yes |
| 9 | suite_0bd662f621264694a72a4de7a16f968d | 538d0a67372b4178b5427189777b1b2d | ad856056a2a64b80ae8c0f03cadd2f4e | 5 | 0 | yes |
| 10 | suite_4d4b25a21b5c4e94bd1898823d2d366a | 0941e3d72659442fb7951ced4e8d2471 | 47939772c2614ca592caeb3bb77b856f | 5 | 0 | yes |

Reproduction: 10/10. Infrastructure failures: 0 (every run: execution succeeded, evidence
complete, all DeepSeek responses HTTP 200, no egress besides the model route).
Exploration run before freezing: suite_49658aa2ab0f4698b357e02d06b05dd5 (4 todo_write, 0 plan), not counted.

Checks for other explanations:
- ABB dropping `plan` updates: ABB's ACP client emits every `session/update` it receives
  (`agentbench/adapter/acp/client.py:36-47`); the same steps record `available_commands_update`
  and `session_info_update`; the image's `agent-client-protocol` 0.12.1 parses a `plan`
  notification of exactly llxprt's shape (`buildZedPlanUpdate`) as `AgentPlanUpdate`.
- `todo_write` failing: every counted call returned `status: success` with the todo progress
  text to the model, and statuses moved from pending/in_progress to completed.
- Same ACP session: each run is one `session/new` and one prompt.

## Upstream (searched after the 10 runs)

- vybestack/llxprt-code issues and PRs searched for todo/plan/zed/ACP terms: no report of
  missing plan updates. #1603 ("ACP SDK full integration", closed 2026-07-28) lists "plans"
  among the `sessionUpdate` kinds the integration uses.
- Current `main` moved the integration to `packages/zed-acp` (#3306) and now subscribes with
  `subscribeSessionTodos(this.id, ...)`; whether that fixes the id mismatch was not verified.

## H1

Rejected; see `h1/NOTES.md`. The tool-level mismatch (`Stderr: (empty)` hardcoded in
`shell.ts:682`) is deterministic, but the agent compensated in all three versions.
