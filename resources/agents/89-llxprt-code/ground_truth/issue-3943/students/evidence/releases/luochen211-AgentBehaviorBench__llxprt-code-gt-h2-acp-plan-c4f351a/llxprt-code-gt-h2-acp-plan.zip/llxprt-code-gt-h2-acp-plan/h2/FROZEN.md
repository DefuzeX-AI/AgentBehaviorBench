# H2 frozen configuration (set before the 10 independent runs)

- ABB unit: `resources/agents/78-llxprt-code` at branch `onboard/llxprt-code-483`, commit
  `c4f351ad7b82f989ed6d35c1e2208004f4749664` (the only uncommitted change is `enabled = true`
  in `resources/registry.toml`, needed to run an `adapting` Agent locally).
- Agent: npm `@vybestack/llxprt-code@0.11.0` (tag `v0.11.0`, commit
  `5400f65a6c7eef52844697c8f8c85390df29eea1`), installed from the integrity-checked lockfile.
- Case: `h2/case-v1.json`, sha256 `e87de405879f06864a1cab1af3bf16eea58ca09c350a2b5a8add10660d3d4dc5`
  (1 step, unchanged since the exploration run).
- Model: deepseek/deepseek-flash at `https://api.deepseek.com` (`ABB_MODEL_PROVIDER=deepseek`,
  `DEEPSEEK_MODEL=deepseek-flash`); no Judge (`--sdk native`).
- Command: `ABB_MODEL_PROVIDER=deepseek agentbench evaluate llxprt-code --sdk native --case-file h2/case-v1.json --cases 1 --max-steps 1 --no-view -y`
  (wrapper `run_case.sh`).
- Environment reset: every run is a separate ABB Suite with a fresh container, an empty
  workspace and a disposable HOME; the unit's ignored `agent/` is removed and prepared afresh
  before each run.
- Reproduction criterion (written before the runs): the step has at least one `todo_write`
  tool call that completed successfully, and the step's ACP log has no `session/update`
  with `sessionUpdate: "plan"`. Not reproduced: a `plan` update appears. Not reached: no
  successful `todo_write` call (counted as "no", not as an infrastructure failure).
  Infrastructure failure (execution not COMPLETED, model/provider error, interception or
  egress rejection): rerun, not counted.
- Exploration run before freezing: `suite_49658aa2ab0f4698b357e02d06b05dd5` (4 successful
  `todo_write` calls, 0 `plan` updates); not counted.
