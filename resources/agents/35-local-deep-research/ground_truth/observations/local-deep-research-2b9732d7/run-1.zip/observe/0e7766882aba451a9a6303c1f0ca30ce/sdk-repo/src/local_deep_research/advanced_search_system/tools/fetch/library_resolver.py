"""Resolve ``fetch_content`` URLs that aren't actually network URLs.

The LangGraph agent's ``fetch_content`` tool receives two URL-shaped
strings that the egress policy correctly rejects as
``unsupported_scheme`` (and that the original ``ContentFetcher`` would
not know how to fetch even without a policy gate):

1. **Local library document references** like
   ``/library/document/<uuid>``, ``/library/document/<uuid>/chunks#chunk-3``,
   ``/lib/document/<uuid>``, ``https://library.document/<uuid>``, or
   ``[<uuid>]``.
   The library RAG search engine and the collection search engine emit
   these as the citation URL of a search hit (see
   ``web_search_engines.engines.search_engine_library.LibraryRAGSearchEngine.search``
   and ``...search_engine_collection.CollectionSearchEngine._get_document_url``).
   The URL points at the user's own library — a local DB read, not a
   network fetch — and resolving it via ``DocumentChunk.chunk_text`` (when
   a chunk anchor is provided) or ``Document.text_content`` is what
   the human user would see if they clicked the link in the UI.

2. **Bare citation markers** like ``[1062]``, ``[1084]``. The agent
   sometimes pastes a citation marker it saw in the search-results block
   back into the tool instead of the actual URL. ``SearchResultsCollector``
   already maps URL → index; the inverse ``find_by_index`` lets the tool
   resolve ``[N]`` back to its source.

Both shapes are intercepted here BEFORE the egress policy gate, so the
agent gets the real page content (or a helpful error) instead of a
generic "blocked by egress policy" denial that wastes a fetch slot
(A3 in ``research_f3045c5b_issue_analysis.md``).

Both the path and bracket forms bind the document id to the canonical
32/64-hex-or-UUID pattern, so a guessable filename (``report.pdf``) is
rejected at the regex instead of relying on a downstream DB miss.
Resolution always runs inside ``get_user_db_session(username)``, so a
parsed reference can still only return a document the caller already owns.
"""

from __future__ import annotations

import re
import uuid
from dataclasses import dataclass
from typing import Any, Callable, Optional
from urllib.parse import unquote, urlsplit

from loguru import logger

from ....utilities.chunk_anchor import (
    LIBRARY_ROUTE_SUFFIX_ALTERNATION,
    is_safe_document_id,
)
from ....utilities.url_utils import is_valid_chunk_fragment

# Canonical document IDs are 32/64-hex blobs or a UUID. The path form is
# bound to this same pattern as the bracket form (below) so a guessable
# filename like ``/library/document/report.pdf`` is rejected at the regex
# rather than reaching the DB only to miss.
_DOCUMENT_ID_PATTERN = (
    r"(?:"
    r"[0-9a-fA-F]{32}|"
    r"[0-9a-fA-F]{64}|"
    r"[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-"
    r"[0-9a-fA-F]{4}-[0-9a-fA-F]{12}"
    r")"
)
# Match canonical paths and the ``/lib/document/...`` abbreviation observed
# in agent tool calls. The same suffix is used by download_service.
#
# ``chunks`` is accepted alongside ``pdf`` because the library/collection
# RAG engines cite chunk-targeted URLs (``/library/document/<id>/chunks``
# plus a ``#chunk-<n>`` fragment) since #5381.
_LIBRARY_PATH_RE = re.compile(
    rf"^/(?:library|lib)/document/(?P<doc_id>{_DOCUMENT_ID_PATTERN})"
    rf"(?:/(?P<suffix>{LIBRARY_ROUTE_SUFFIX_ALTERNATION}))?/?$"
)
_BRACKETED_DOCUMENT_RE = re.compile(
    rf"^\[(?P<doc_id>{_DOCUMENT_ID_PATTERN})\]$"
)

# Match ``[N]`` — a 1-based citation marker with no surrounding chars.
# The agent emits this verbatim when it confuses the citation marker for
# a URL; we resolve it via SearchResultsCollector.find_by_index.
_CITATION_REF_RE = re.compile(r"^\[(\d+)\]$")


@dataclass(frozen=True)
class _LibraryReference:
    value: str
    suffix: Optional[str] = None
    #: True when the reference arrived as the bare ``[<uuid>]`` alias
    #: rather than as a route. That spelling is not a URL at all, so
    #: registering it verbatim as the citation link gives the document a
    #: THIRD bibliography entry alongside its ``/library/document/<id>``
    #: and ``https://library.document/<id>`` citations — and renders a
    #: dead link. Callers re-emit the canonical route instead.
    bracketed: bool = False
    chunk_index: Optional[int] = None


def _decode_segment(value: str) -> str | None:
    """Percent-decode one path segment, refusing separators and controls.

    Now that ``_LIBRARY_PATH_RE``'s doc_id group is bound to hex/UUID, the only
    live call site can never hand this a ``%``, so ``unquote`` is a no-op there
    and none of the checks below fire. It is kept deliberately rather than
    inlined away: it is the guard that makes loosening that group safe, and
    deleting it would silently remove the safety net for whoever does. Anyone
    widening the doc_id charset should confirm this is reachable again.
    """
    decoded = unquote(value)
    if (
        not decoded
        or any(char in decoded for char in ("/", "\\", "?", "#"))
        or any(ord(char) < 32 or ord(char) == 127 for char in decoded)
    ):
        return None
    return decoded


def _parse_library_reference(url: str) -> _LibraryReference | None:
    if not isinstance(url, str):
        return None

    candidate = url.strip()
    if not candidate:
        return None

    # Extract any validated ``#chunk-<n>`` fragment before splitting the path.
    # Chunk citations carry ``#chunk-<n>``, which addresses a specific chunk.
    # We record the index and strip the fragment before the ``://`` test so that
    # (a) the ``https://library.document/<id>/chunks#chunk-3`` alias is not
    # rejected by the absolute branch's no-fragment rule, and (b) a
    # relative path whose fragment happens to contain ``://``
    # (``/library/document/<id>#http://x``) is not misrouted into it.
    chunk_index: Optional[int] = None
    if "#" in candidate:
        head, fragment = candidate.split("#", 1)
        candidate = head
        if is_valid_chunk_fragment(fragment):
            chunk_index = int(fragment[len("chunk-") :])
    if not candidate:
        return None

    if "://" in candidate:
        parsed = urlsplit(candidate)
        # No ``parsed.fragment`` check: the fragment was stripped above, so
        # it can never reach here. A query still disqualifies — it can carry
        # server-meaningful state, unlike a client-side anchor.
        if (
            parsed.scheme != "https"
            or parsed.netloc != "library.document"
            or parsed.query
        ):
            return None
        candidate = f"/library/document{parsed.path}"

    path_match = _LIBRARY_PATH_RE.match(candidate)
    if path_match:
        doc_id = _decode_segment(path_match.group("doc_id"))
        if doc_id is None:
            return None
        return _LibraryReference(
            doc_id, path_match.group("suffix"), chunk_index=chunk_index
        )

    bracket_match = _BRACKETED_DOCUMENT_RE.match(candidate)
    if bracket_match:
        return _LibraryReference(
            bracket_match.group("doc_id"),
            bracketed=True,
            chunk_index=chunk_index,
        )

    return None


def parse_library_url(url: str) -> tuple[str, Optional[str]] | None:
    """Return the local document reference and optional suffix, else ``None``.

    ``suffix`` is ``"pdf"`` for the PDF-direct form, ``"chunks"`` for the
    chunk-listing route that RAG citations point at, and ``None`` for the
    root document page. Any ``#fragment`` (e.g. ``#chunk-3``) is stripped
    before matching, so a chunk-targeted citation resolves to its
    document. In addition to canonical library paths, this accepts
    the ID-bound aliases emitted by the agent. The ``doc_id`` segment must
    match the canonical document-ID pattern (32/64-hex or UUID), so
    filename-shaped values like ``report.pdf`` are rejected here and fall
    through to the egress-denial path; any accepted reference is still
    scoped to the caller's own documents by ``get_user_db_session`` at
    lookup time.
    """
    reference = _parse_library_reference(url)
    if reference is None:
        return None
    return reference.value, reference.suffix


def is_citation_reference(url: str) -> int | None:
    """If *url* is a bare ``[N]`` citation marker, return ``N`` (int), else ``None``."""
    if not isinstance(url, str):
        return None
    m = _CITATION_REF_RE.match(url.strip())
    if not m:
        return None
    return int(m.group(1))


def resolve_library_document(
    url: str, username: Optional[str]
) -> Optional[dict[str, Any]]:
    """Look up a local library document by ``/library/document/<uuid>[/pdf]`` URL.

    When the URL includes a chunk anchor (e.g. ``/library/document/<uuid>/chunks#chunk-3``),
    retrieves the specific chunk text from ``DocumentChunk`` rather than the whole document.
    If no chunk anchor is present, resolves to ``Document.text_content``. If a chunk anchor
    is present but the chunk is missing, reports that the chunk was not found rather than
    silently falling back to the whole document.

    Returns a dict shaped like the fetch tool's success payload (``title``,
    ``content``) so callers can pass it straight to ``_register_in_collector``
    + the ``[N] Title:\\nURL:\\n\\n<body>`` formatter. The ``url`` field of
    the dict is the *original* library URL, so a downstream re-citation still
    reads "library/document/…" instead of something more confusing — except
    for the bare ``[<uuid>]`` alias, which is not a URL at all and is
    re-emitted as the resolved document's canonical route so it shares a
    bibliography entry with the document's other citations.

    Returns ``None`` for:

    - URLs that don't match ``/library/document/...``
    - Documents the user can't access (no ``username`` or no row found).
      Callers should fall through to the egress policy / HTTP fetcher
      for these so a malformed UUID produces the normal "blocked by
      egress policy" outcome instead of a misleading custom error.

    (Documents with empty text content return a result payload with
    ``content=""``, which summary-mode handles as NOT RELEVANT without an
    LLM call.)
    """
    reference = _parse_library_reference(url)
    if reference is None:
        return None
    lookup_value = reference.value
    chunk_index = reference.chunk_index

    if not username:
        # No user context → no library. Caller falls through to the
        # egress policy, which rejects the URL as ``unsupported_scheme``.
        return None

    # Lazy imports: avoid pulling SQLAlchemy / user-DB modules into the
    # module-load path for the (common) no-library case.
    try:
        from local_deep_research.database.models.library import (
            Document,
            DocumentChunk,
        )
        from local_deep_research.database.session_context import (
            get_user_db_session,
        )
    except Exception:
        logger.exception(
            "library_resolver: failed to import DB modules for document "
            "lookup (url={!r})",
            url,
        )
        return None

    try:
        with get_user_db_session(username) as session:
            query = session.query(Document)
            document = query.filter_by(id=lookup_value).first()
            if document is None:
                document = query.filter_by(document_hash=lookup_value).first()
            if document is None and re.fullmatch(
                r"[0-9a-fA-F]{32}", lookup_value
            ):
                canonical_id = str(uuid.UUID(hex=lookup_value))
                document = query.filter_by(id=canonical_id).first()
            if document is None:
                return None

            chunk = None
            if chunk_index is not None:
                chunk = (
                    session.query(DocumentChunk)
                    .filter(
                        DocumentChunk.source_id == document.id,
                        DocumentChunk.chunk_index == chunk_index,
                    )
                    .order_by(DocumentChunk.collection_name, DocumentChunk.id)
                    .first()
                )
                if chunk is not None:
                    text = chunk.chunk_text or ""
                else:
                    text = f"Chunk {chunk_index} not found for document {document.id}."
            else:
                text = document.text_content or ""

            citation_url = url
            if reference.bracketed:
                # Built from the RESOLVED row's id, not from the alias
                # value: the lookup above also accepts a document_hash and
                # a dash-less UUID, neither of which is a live route.
                resolved_id = str(document.id or "")
                if is_safe_document_id(resolved_id):
                    citation_url = f"/library/document/{resolved_id}"
                else:
                    # Practically unreachable — ``Document.id`` is a UUID —
                    # but silence here leaves ``citation_url`` as the raw
                    # ``[uuid]`` alias, which is not a route: a dead link
                    # that also keys separately from the document's other
                    # citations. Log it rather than let it look intended.
                    logger.warning(
                        "library_resolver: resolved document id is not "
                        "route-safe, citation left as the bracketed alias "
                        "(id={!r})",
                        resolved_id,
                    )
            return {
                "title": document.title or f"Document {lookup_value}",
                "content": text,
                "url": citation_url,
                # ``snippet`` is what the collector registers as the
                # citation preview. Use the title fallback when text is
                # empty so the agent still gets *something* descriptive.
                "snippet": (
                    text[:200].strip() if text else document.title or ""
                )
                or "",
            }
    except Exception:
        # Match the existing LibraryRAGSearchEngine behaviour: a per-document
        # DB hiccup is non-fatal; the tool returns a clean "not found" via
        # None and the caller can fall through.
        logger.exception(
            "library_resolver: failed to load document "
            "(reference={!r}, username={!r})",
            lookup_value,
            username,
        )
        return None


def make_library_resolver(
    username: Optional[str],
) -> Callable[[str], Optional[dict[str, Any]]]:
    """Build a one-arg URL → dict resolver suitable for the fetch tool.

    Captures *username* in the closure so subagent workers (which don't
    inherit thread-local Flask session state) can resolve library URLs
    using the run's user, the same way the LangGraph strategy threads
    ``settings_snapshot`` and ``egress_context`` through tool closures.

    Returns the resolved dict, or ``None`` for URLs that aren't library
    document refs — the fetch tool then falls through to the egress gate
    unchanged.
    """
    # Bind the username once so the inner function doesn't re-resolve on
    # every call (cheap, but keeps the per-call hot path branch-free).
    _username = username

    def _resolve(url: str) -> Optional[dict[str, Any]]:
        return resolve_library_document(url, _username)

    return _resolve


def resolve_citation_reference(
    url: str,
    collector: Any,
) -> Optional[dict[str, Any]]:
    """Resolve a bare ``[N]`` citation marker to its source result dict.

    Returns the result dict (with at least ``link``/``url`` and ``title``
    populated, mirroring ``SearchResultsCollector.find_by_index``) when
    the marker matches a tracked citation, else ``None``. The fetch tool
    uses ``None`` as a signal to return a helpful "no such citation"
    error to the agent instead of falling through to the egress gate
    (where the marker would also be rejected as ``unsupported_scheme``,
    but with a less actionable message).
    """
    idx = is_citation_reference(url)
    if idx is None:
        return None
    if collector is None:
        return None
    find = getattr(collector, "find_by_index", None)
    if not callable(find):
        return None
    return find(idx)
