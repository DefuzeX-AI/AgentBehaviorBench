import { useState } from "react"
import type { JobMatch } from "../../types"
import { SRC_LABEL } from "../../lib/sources"
import { Card } from "../../ui/Card"
import { Button } from "../../ui/Button"
import { Badge } from "../../ui/Badge"
import { Sparkles, ExternalLink, ChevronLeft, ChevronRight } from "../../ui/icons"
import { jobExperienceLabel } from "./experience"
import { getPaginationItems } from "./pagination"
import { jobWorkModeBadge } from "../../lib/workMode"

const PAGE_SIZE = 8

// 適配以高/中/低色帶呈現（內部仍用 fit_score 排序/篩選）；避免與投遞包的「匹配評分」數字打架。
function fitBand(s: number) {
  return s >= 80 ? { label: "高", cls: "from-emerald-500 to-emerald-600" }
    : s >= 60 ? { label: "中", cls: "from-amber-500 to-amber-600" }
      : { label: "低", cls: "from-slate-400 to-slate-500" }
}

function FitBadge({ score }: { score: number }) {
  const b = fitBand(score)
  return (
    <div className={`shrink-0 w-14 h-14 rounded-xl bg-gradient-to-br ${b.cls} text-white grid place-items-center text-center`}>
      <div className="text-xl font-bold leading-none">{b.label}</div>
      <div className="text-[9px] opacity-85 mt-0.5">適配</div>
    </div>
  )
}

function evidenceLabel(level?: JobMatch["evidence_level"]) {
  if (level === "high") return "資料完整度高"
  if (level === "medium") return "資料完整度中"
  if (level === "low") return "資料完整度低"
  return ""
}

function JobCard(
  { m, onPick, pending, allowPackageGeneration }:
  {
    m: JobMatch
    onPick: (m: JobMatch) => void
    pending?: boolean
    allowPackageGeneration: boolean
  },
) {
  const exp = jobExperienceLabel(m.job)
  const workMode = jobWorkModeBadge(m.job)
  const evidence = evidenceLabel(m.evidence_level)
  return (
    <Card interactive className="p-4 flex flex-col sm:flex-row gap-4 animate-fade-in-up">
      <FitBadge score={m.fit_score} />
      <div className="flex-1 min-w-0">
        <div className="flex flex-wrap items-center gap-2">
          <a href={m.job.url} target="_blank" rel="noreferrer"
            className="font-medium text-slate-900 hover:text-brand-700 hover:underline rounded focus:outline-none focus-visible:ring-2 focus-visible:ring-brand-300">{m.job.title}</a>
          <Badge tone={m.job.source === "careers" ? "brand" : "slate"}>{SRC_LABEL[m.job.source] || m.job.source}</Badge>
          {workMode && <Badge tone={workMode.tone}>{workMode.label}</Badge>}
          {evidence && <Badge tone="slate">{evidence}</Badge>}
        </div>
        <p className="text-sm text-slate-600 mt-0.5">
          {m.job.company}
          {m.job.location ? `｜${m.job.location}` : ""}
          {m.job.salary ? `｜${m.job.salary}` : ""}
          {exp ? `｜${exp}` : ""}
        </p>
        {m.reason && <p className="text-sm text-slate-700 mt-1">{m.reason}</p>}
        {m.matched.length > 0 && (
          <div className="flex flex-wrap gap-1.5 mt-2">
            {m.matched.map((t, k) => <Badge key={k} tone="emerald">{t}</Badge>)}
          </div>
        )}
        {m.gaps.length > 0 && (
          <div className="flex flex-wrap gap-1.5 mt-1.5">
            {m.gaps.slice(0, 4).map((t, k) => <Badge key={k} tone="amber">待確認：{t}</Badge>)}
          </div>
        )}
      </div>
      <div className="shrink-0 flex flex-row sm:flex-col gap-2">
        {allowPackageGeneration && (
          <Button size="sm" icon={Sparkles} loading={pending} onClick={() => onPick(m)} className="whitespace-nowrap">產生投遞包</Button>
        )}
        <a href={m.job.url} target="_blank" rel="noreferrer"
          className="inline-flex items-center justify-center gap-1 px-3 py-1.5 bg-slate-100 text-slate-600 rounded-lg text-sm hover:bg-slate-200 transition whitespace-nowrap focus:outline-none focus-visible:ring-2 focus-visible:ring-brand-300">
          <ExternalLink className="w-3.5 h-3.5" />看原職缺
        </a>
      </div>
    </Card>
  )
}

// 可分頁的職缺清單；onPick 可為 async（抓完整 JD 時該卡按鈕顯示載入中）。
export function JobList({ matches, onPick, allowPackageGeneration = true }:
  {
    matches: JobMatch[]
    onPick: (m: JobMatch) => void | Promise<void>
    allowPackageGeneration?: boolean
  }) {
  const [page, setPage] = useState(1)
  const [pendingUrl, setPendingUrl] = useState("")
  // 新一輪結果（matches 參考改變）→ 在 render 期回到第 1 頁（React 官方「prop 改變時
  // 調整 state」做法：用 state 記錄上一批比對，免 effect、不讀寫 ref）。
  const [prevMatches, setPrevMatches] = useState(matches)
  if (prevMatches !== matches) {
    setPrevMatches(matches)
    setPage(1)
  }
  const totalPages = Math.max(1, Math.ceil(matches.length / PAGE_SIZE))
  const cur = Math.min(page, totalPages)
  const pageItems = getPaginationItems(cur, totalPages)

  async function handle(m: JobMatch) {
    if (pendingUrl) return  // 已有一張卡在抓 JD/開跑 → 忽略連點，避免同時觸發多條 pipeline
    setPendingUrl(m.job.url)
    try { await onPick(m) } finally { setPendingUrl("") }
  }

  return (
    <>
      <div className="space-y-3">
        {matches.slice((cur - 1) * PAGE_SIZE, cur * PAGE_SIZE).map((m, i) => (
          <JobCard
            key={i}
            m={m}
            onPick={handle}
            pending={!!pendingUrl && m.job.url === pendingUrl}
            allowPackageGeneration={allowPackageGeneration}
          />
        ))}
      </div>
      {matches.length > PAGE_SIZE && (
        <nav aria-label="職缺分頁"
          className="mt-5 flex flex-wrap items-center justify-center gap-2 rounded-lg border border-slate-200 bg-white px-2 py-2 shadow-sm">
          <Button variant="secondary" size="sm" icon={ChevronLeft}
            aria-label="上一頁" title="上一頁"
            className="h-9 w-9 px-0" disabled={cur <= 1} onClick={() => setPage(Math.max(1, cur - 1))} />
          <div className="flex items-center gap-1">
            {pageItems.map((item, i) => item === "ellipsis" ? (
              <span key={`ellipsis-${i}`} aria-hidden="true"
                className="h-9 w-7 grid place-items-center text-sm text-slate-400">…</span>
            ) : (
              <button key={item} onClick={() => setPage(item)} aria-current={item === cur ? "page" : undefined}
                className={`h-9 min-w-9 rounded-md px-2 text-sm font-medium transition focus:outline-none focus-visible:ring-2 focus-visible:ring-brand-300 ${
                  item === cur ? "bg-brand-600 text-white shadow-sm" : "text-slate-600 hover:bg-slate-100"
                }`}>{item}</button>
            ))}
          </div>
          <Button variant="secondary" size="sm" icon={ChevronRight}
            aria-label="下一頁" title="下一頁"
            className="h-9 w-9 px-0" disabled={cur >= totalPages} onClick={() => setPage(Math.min(totalPages, cur + 1))} />
          <span className="basis-full text-center text-xs text-slate-500 sm:basis-auto sm:min-w-[4.5rem]">
            第 {cur} / {totalPages} 頁
          </span>
        </nav>
      )}
    </>
  )
}
