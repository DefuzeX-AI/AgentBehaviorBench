"""應用層 sqlite（與 LangGraph checkpoints 分開）：歷史投遞包 + 使用者記憶。

單一共用連線（check_same_thread=False 供 FastAPI threadpool 共用）；寫入用 LOCK 串行化。
路徑由 COPILOT_APP_DB 決定，預設 data/app.sqlite；測試用 :memory:（單例連線共用同一 in-memory DB）。
"""
from __future__ import annotations

import os
import sqlite3
import threading
from pathlib import Path

_ROOT = Path(__file__).parent.parent.parent
LOCK = threading.Lock()
_conn: sqlite3.Connection | None = None


def _db_path() -> str:
    return os.environ.get("COPILOT_APP_DB", str(_ROOT / "data" / "app.sqlite"))


def _init(conn: sqlite3.Connection) -> None:
    conn.execute(
        "CREATE TABLE IF NOT EXISTS packages("
        "id INTEGER PRIMARY KEY AUTOINCREMENT, created_at TEXT, job_title TEXT, company TEXT, "
        "match_score INTEGER, jd_text TEXT, profile_json TEXT, package_json TEXT, approved INTEGER, "
        "thread_id TEXT)")
    # 既有資料庫缺欄位時補上：thread_id（冪等存檔用）、status（背景產生的生命週期）。
    cols = {r[1] for r in conn.execute("PRAGMA table_info(packages)").fetchall()}
    if "thread_id" not in cols:
        conn.execute("ALTER TABLE packages ADD COLUMN thread_id TEXT")
    if "status" not in cols:
        # 既有列視為已完成；新列先為 'running'，跑完有文件轉 'done'，無文件轉 'stopped'，失敗 'failed'。
        conn.execute("ALTER TABLE packages ADD COLUMN status TEXT DEFAULT 'done'")
    conn.execute(
        "CREATE TABLE IF NOT EXISTS user_memory("
        "id INTEGER PRIMARY KEY CHECK (id=1), profile_json TEXT, preferences_json TEXT, updated_at TEXT)")
    conn.execute(
        "CREATE TABLE IF NOT EXISTS searches("
        "id INTEGER PRIMARY KEY AUTOINCREMENT, created_at TEXT, label TEXT, "
        "ai_count INTEGER, company_count INTEGER, profile_json TEXT, payload_json TEXT)")
    conn.execute(
        "CREATE TABLE IF NOT EXISTS resume_checks("
        "id INTEGER PRIMARY KEY AUTOINCREMENT, created_at TEXT, label TEXT, resume_label TEXT, "
        "candidate_name TEXT, overall_score INTEGER, assessment_mode TEXT, fallback_reason TEXT, "
        "profile_json TEXT, assessment_json TEXT)")
    conn.commit()


def get_conn() -> sqlite3.Connection:
    global _conn
    if _conn is None:
        _conn = sqlite3.connect(_db_path(), check_same_thread=False)
        _conn.row_factory = sqlite3.Row
        _init(_conn)
    return _conn


def init_db() -> None:
    get_conn()
